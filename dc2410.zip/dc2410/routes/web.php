<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Http\Controllers\EventViewController;
use App\Http\Controllers\OrganiserViewController;
use App\Http\Controllers\DetailedEventsController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login', function (){
    return view('login');
});

Route::get('/createevent', function (){
    return view('createevent');
})->middleware('auth');

Route::get('/createcategory', function (){
    return view('createcategory');
})->middleware('auth');

Route::get('/viewevents',[EventViewController::class, 'index']);

Route::get('/viewevents/{id}', [DetailedEventsController::class, 'index']);

Route::get('/viewevents/{id}/vote', function($id){
  DB::table('events')
    -> where('EventID', $id)
    -> increment('Interest');
});

Route::get('/vieworganisedevents',[OrganiserEventsController::class, 'index']);

Route::get('/vieworganisers',[OrganiserViewController::class, 'index']);


Route::post('/submitUser', function(Request $request)
{
  $username = $request->input('username');
  $firstname = $request->input('firstname');
  $surname = $request->input('surname');
  $password = $request->input('password');
  $phoneno = $request->input('phoneno');
  $email = $request->input('email');

  $user = User::create([
      'username' => $username,
      'firstname' => $firstname,
      'surname' => $surname,
      'password' => bcrypt($password),
      'phoneno' => $phoneno,
      'emailaddress' => $email
  ]);
  Auth::login($user);
  return redirect('/viewevents');
});


Route::post('/submitEvent', function(Request $request)
{
  $eventname = $request->input('eventname');
  $category = $request->input('category');
  $description = $request->input('description');
  $date = $request->input('date');
  $time = $request->input('time');
  $place = $request->input('place');
  $interest = $request->input('interest');
  $photo = $request->input('photo');

  DB::table('events')->insert([
      'EventName' => $eventname,
      'CategoryID' => $category,
      'Description' => $description,
      'EventDate' => $date,
      'EventTime' => $time,
      'Place' => $place,
      'Interest' => $interest,
      'Photo' => $photo
  ]);
  return redirect('/viewevents');
});


Route::post('/submitCategory', function(Request $request)
{
  $category = $request->input('category');

  DB::table('category')->insert([
      'CategoryName' => $category,
  ]);
  return redirect('/viewevents');
});

Route::post('/submitLogin', function(Request $request)
{
  $username = $request->input('username');
  $password = bcrypt($request->input('password'));

  $user = User::where('Username', $username)
    ->where('Password', $password)
    ->first();

  if(isset($user)){
    Auth::login($user, true);
    return redirect('/createevent');
  }

  return redirect('/login');
});

Route::get('/submitLogin',[LoginController::class, 'index']);
