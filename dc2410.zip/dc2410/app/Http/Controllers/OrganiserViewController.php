<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
class OrganiserViewController extends Controller {
public function index(){
$organisers = DB::select('select OrganiserID, Firstname, Surname, EmailAddress from organiser');
return view('vieworganisers')->with('organiser', $organisers);

}
}
