<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
class EventViewController extends Controller {
public function index(){
$events = DB::select('select EventName, Description, EventDate, EventTime, Interest from events');
return view('viewevents')->with('events', $events);

}
}
