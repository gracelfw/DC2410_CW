<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
class LoginController extends Controller {
public function index(){
  $user = Organiser::where('Username', $username)
                 ->where('Password', $password)
                 ->get();
return redirect('/createevent');

}
}
