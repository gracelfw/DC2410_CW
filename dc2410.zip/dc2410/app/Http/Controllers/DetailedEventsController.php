<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
class DetailedEventsController extends Controller {
public function index($id){
$events =collect(DB::table('events')
            -> where('EventId', $id)
            -> get());
return view('viewevents')->with('events', $events);

}
}
