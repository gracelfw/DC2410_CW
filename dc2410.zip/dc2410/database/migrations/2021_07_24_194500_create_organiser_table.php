<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrganiserTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('organiser', function (Blueprint $table) {
            $table->increments('OrganiserID');
            $table->string('Username', 50)->unique();
            $table->string('Firstname', 25);
            $table->string('Surname', 50);
            $table->string('Password');
            $table->string('PhoneNo', 11)->nullable($value = true);
            $table->string('EmailAddress', 50);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('organiser');
    }
}
