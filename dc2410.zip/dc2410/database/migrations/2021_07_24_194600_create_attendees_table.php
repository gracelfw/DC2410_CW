<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAttendeesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('attendees', function (Blueprint $table) {
            $table->unsignedInteger('OrganiserID');
            $table->unsignedInteger('EventID');

            $table->primary(['OrganiserID', 'EventID']);
            $table->foreign('OrganiserID')->references('OrganiserID')->on('organiser');
            $table->foreign('EventID')->references('EventID')->on('events');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('attendees');
    }
}
