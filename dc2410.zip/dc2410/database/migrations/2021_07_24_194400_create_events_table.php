<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEventsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('events', function (Blueprint $table) {
            $table->increments('EventID');
            $table->string('EventName', 50);
            $table->unsignedInteger('CategoryID');
            $table->string('Description', 100);
            $table->date('EventDate');
            $table->time('EventTime');
            $table->string('Place', 50);
            $table->integer('Interest');
            $table->text('Photo')->nullable($value = true);

            $table->foreign('CategoryID')->references('CategoryID')->on('category');
        });

        /*DB::table('events')->insert(
            array(
            'id'=> 1,
            )
        );*/
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('events');
    }
}
