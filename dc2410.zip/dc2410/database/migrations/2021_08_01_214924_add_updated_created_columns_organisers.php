<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddUpdatedCreatedColumnsOrganisers extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('organiser', function (Blueprint $table) {
		$table->date('created_at')->default('2021-08-01');
             $table->date('updated_at')->default('2021-08-01');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('organiser', function (Blueprint $table) {
            //
        });
    }
}
