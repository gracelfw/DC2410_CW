<!DOCTYPE html>
<html>
    <body>
        <h1> Log in</h1>

        <form method="post" action="submitLogin">
          @csrf
          Username: <input type="text" name="username" required><br>
          Password: <input type="password" name="password" required><br>
          <input type="hidden" name=“submitted” value=“true”/>
          <input type="submit" onclick="submitLogin" name="login_button" value="Log in">
        </form>
        <form method="get" action="viewevents">
          <button type="submit" onclick="viewevents" value="View Events">View Events</button>
        </form>

    </body>
</html>
