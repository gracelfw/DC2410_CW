<!DOCTYPE html>
<html>
    <body>
        <h1> Organisers:</h1>

        <table border = "1">
          <tr>
            <td>Organiser ID</td>
            <td>First Name</td>
            <td>Surname</td>
            <td>Email Address</td>
          </tr>

          @foreach ($organiser as $organiser)
          <tr>
            <td>{{$organiser->OrganiserID}}</td>
            <td>{{$organiser->Firstname}}</td>
            <td>{{$organiser->Surname}}</td>
            <td>{{$organiser->EmailAddress}}</td>
            @endforeach
          </table>
          </tr>

          <form method="get" action="index.php">
            <button type="submit" onclick="" value="Go Home">Go Home</button>
          </form>
    <body>
</html>
