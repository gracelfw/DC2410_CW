<!DOCTYPE html>
<html>
    <body>
        <h1> Events:</h1>

        <table border = "1">
          <tr>
            <td>Event Name</td>
            <td>Category ID</td>
            <td>Description</td>
            <td>Date</td>
            <td>Time</td>
            <td>Interest</td>
            
          </tr>

          @foreach ($events as $event)
          <tr>
            <td>{{$event->EventName}}</td>
            <td>{{$event->CategoryID}}</td>
            <td>{{$event->Description}}</td>
            <td>{{$event->EventDate}}</td>
            <td>{{$event->EventTime}}</td>
            <td>{{$event->Interest}}</td>

            @endforeach
          </table>
          </tr>


          <form method="get" action="createcategory">
            <button type="submit" onclick="createcategory" value="Add New Category">Add New Category</button>
          </form>
          <form method="get" action="index.php">
            <button type="submit" onclick="" value="Go Home">Go Home</button>
          </form>

          <?php  if(!isset($_POST['submitted'])){ ?>
              <form method="get" action="createevent">
                <button type="submit" onclick="createevent" value="Add Event">Add New Event</button>
              </form>
            <?php } ?>
    <body>
</html>
