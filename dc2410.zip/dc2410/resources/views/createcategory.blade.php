<!DOCTYPE html>
<html>
    <body>
        <h1>Add new category</h1>

        <form method="post" action="submitCategory">
          @csrf
          Category: <input type="text" name="category"><br>
          <input type="submit" value="Create">
        </form>

        <form method="get" action="viewevents">
          <button type="submit" onclick="viewevents" value="View Events">View Events</button>
        </form>
        <form method="get" action="login">
          <button type="submit" onclick="login" value="Log in">Log In</button>
        </form>
    </body>
</html>
