<!DOCTYPE html>
<html>
  <body>
      <h1> Create New Event </h1>
      <form method="post" action="submitEvent">
        @csrf
        Event Name: <input type="text" name="eventname" required><br>
        Category:<input type="integer" name="category" required><br>
        Description: <input type="textarea" rows="10" name="description" required><br>
        Date: <input type="date" min="2021-01-01" name="date" required><br>
        Time: <input type="time" name="time" required><br>
        Place: <input type="text" name="place" required><br>
        Interest: <input type="integer" name="interest" min="1"><br>
        Photo: <input type="file" name="photo" multiple><br>
        <input type="submit">
      </form>
        <form method="get" action="viewevents">
          <button type="submit" onclick="viewevents" value="View Events">View Events</button>
        </form>
        <form method="get" action="createcategory">
          <button type="submit" onclick="createcategory" value="Create New Category">Create New Category</button>
        </form>


  </body>
</html>
