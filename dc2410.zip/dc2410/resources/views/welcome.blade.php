<!DOCTYPE html>
<html>
    <body>
        <h1> Welcome!</h1>


        <form method="post" action="submitUser">
          @csrf
          Username: <input type="text" name="username" required><br>
          First name:<input type="text" name="firstname" required><br>
          Surname: <input type="text" name="surname" required><br>
          Password: <input type="password" name="password" required><br>
          Phone No: <input type="tel"
            pattern="[0-9]{11}"
            placeholder="12345678912"
            name="phoneno"><br>
          Email: <input type="email" name="email" required><br>
          <input type="hidden" name=“submitted” value=“true”/>
          <input type="submit" name="create_user_button" value="Create new user">
          <input type="reset" value="Clear form">
        </form>
        <form method="get" action="viewevents">
          <button type="submit" onclick="viewevents" value="View Events">View Events</button>
        </form>
        <form method="get" action="vieworganisers">
          <button type="submit" onclick="vieworganisers" value="View Organisers">View Organisers</button>
        </form>
        <form action="login" method="get">
          <button type="submit" onclick="login" value="Log In"> Log in</button>
        </form>



    </body>
</html>
