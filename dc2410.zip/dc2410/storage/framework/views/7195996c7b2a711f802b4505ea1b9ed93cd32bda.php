<!DOCTYPE html>
<html>
    <body>
        <h1> Organisers:</h1>

        <table border = "1">
          <tr>
            <td>Organiser ID</td>
            <td>First Name</td>
            <td>Surname</td>
            <td>Email Address</td>
          </tr>

          <?php $__currentLoopData = $organiser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organiser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($organiser->OrganiserID); ?></td>
            <td><?php echo e($organiser->Firstname); ?></td>
            <td><?php echo e($organiser->Surname); ?></td>
            <td><?php echo e($organiser->EmailAddress); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
          </tr>

          <form method="get" action="/">
            <button type="submit" onclick="/" value="Go Home">Go Home</button>
          </form>
    <body>
</html>
<?php /**PATH C:\Users\grace\Github\DC2410\dc2410\resources\views/vieworganisers.blade.php ENDPATH**/ ?>