<!DOCTYPE html>
<html>
    <body>
        <h1> Events:</h1>

        <form method="get" action="/vieworganisedevents">
          <button type="submit" onclick="/vieworganisedevents" value="Sort By Category">Sort By Category</button>
        </form>

        <table border = "1">
          <tr>
            <td>Event Name</td>
            <td>Description</td>
            <td>Date</td>
            <td>Time</td>
            <td>Interest</td>
            <td>Register</td>
            <td>View Details</td>
          </tr>

          <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($event->EventName); ?></td>
            <td><?php echo e($event->Description); ?></td>
            <td><?php echo e($event->EventDate); ?></td>
            <td><?php echo e($event->EventTime); ?></td>
            <td><?php echo e($event->Interest); ?></td>
            <td><form method="get" action="/viewevents/{EventID}/vote}"><button type="submit" onclick="/viewevents/{EventID}/vote}">Register</button></form></td>
            <td><form method="get" action="/viewevents/{EventID}"><button type="submit" onclick="/viewevents/{EventID}">View Details</button></form></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
          </tr>


          <form method="get" action="/createcategory">
            <button type="submit" onclick="/createcategory" value="Add New Category">Add New Category</button>
          </form>
          <form method="get" action="/">
            <button type="submit" onclick="/" value="Go Home">Go Home</button>
          </form>

          <?php  if(!isset($_POST['submitted'])){ ?>
              <form method="get" action="/createevent">
                <button type="submit" onclick="/createevent" value="Add Event">Add New Event</button>
              </form>
            <?php } ?>
    <body>
</html>
<?php /**PATH C:\Users\grace\Github\DC2410\dc2410\resources\views/viewevents.blade.php ENDPATH**/ ?>